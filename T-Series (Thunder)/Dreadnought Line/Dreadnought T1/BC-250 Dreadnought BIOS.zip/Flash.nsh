AfuEfix64.efi BC250_3.00_CHIPSETMENU.ROM /p /b /n /k /x /rlc:e
reset